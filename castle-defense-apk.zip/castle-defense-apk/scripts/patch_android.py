#!/usr/bin/env python3
"""Run after `npx cap add android`: portrait lock, fullscreen, launcher icon."""
import os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, 'android', 'app', 'src', 'main')

def sub(path, fn):
    try:
        s = open(path, encoding='utf-8').read(); n = fn(s)
        if n != s:
            open(path, 'w', encoding='utf-8').write(n); print('patched', os.path.relpath(path, ROOT))
    except Exception as e:
        print('skip', path, e)

sub(os.path.join(A, 'AndroidManifest.xml'),
    lambda s: s if 'screenOrientation' in s else s.replace('<activity', '<activity android:screenOrientation="portrait"', 1))

def fs(s):
    if 'windowFullscreen' in s: return s
    return re.sub(r'(<style name="AppTheme\.NoActionBar"[^>]*>)',
                  r'\1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>', s, 1)
sub(os.path.join(A, 'res', 'values', 'styles.xml'), fs)

try:
    from PIL import Image
    ico = Image.open(os.path.join(ROOT, 'resources', 'icon.png')).convert('RGBA')
    for d, px in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
        dd = os.path.join(A, 'res', 'mipmap-' + d)
        if not os.path.isdir(dd): continue
        for nm in ('ic_launcher.png', 'ic_launcher_round.png'):
            ico.resize((px, px), Image.LANCZOS).save(os.path.join(dd, nm))
        fg = Image.new('RGBA', (px * 108 // 48, px * 108 // 48), (0, 0, 0, 0))
        inner = ico.resize((px * 72 // 48, px * 72 // 48), Image.LANCZOS)
        o = (fg.size[0] - inner.size[0]) // 2; fg.paste(inner, (o, o), inner)
        fg.save(os.path.join(dd, 'ic_launcher_foreground.png'))
    bg = os.path.join(A, 'res', 'values', 'ic_launcher_background.xml')
    if os.path.exists(bg):
        open(bg, 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#1c1226</color>\n</resources>\n')
    print('icons written')
except Exception as e:
    print('icon step skipped:', e)
