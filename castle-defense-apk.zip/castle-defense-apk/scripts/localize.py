#!/usr/bin/env python3
"""Download every external <script src> / Google-Fonts CSS used by www/index.html into www/libs
and rewrite index.html so the APK works fully OFFLINE.  Needs internet only while running this."""
import re, os, urllib.request
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IDX = os.path.join(ROOT, 'www', 'index.html')
LIBS = os.path.join(ROOT, 'www', 'libs')
os.makedirs(LIBS, exist_ok=True)
html = open(IDX, encoding='utf-8').read()
UA = {'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'}

def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()

for url in sorted(set(re.findall(r'<script[^>]*\bsrc="(https?://[^"]+)"', html))):
    name = url.split('/')[-1].split('?')[0]
    print('script', url)
    open(os.path.join(LIBS, name), 'wb').write(get(url))
    html = html.replace(url, 'libs/' + name)

for url in re.findall(r'<link[^>]*href="(https://fonts\.googleapis\.com/[^"]+)"', html):
    print('fonts', url)
    css = get(url).decode('utf-8')
    fdir = os.path.join(LIBS, 'fonts'); os.makedirs(fdir, exist_ok=True)
    for i, furl in enumerate(sorted(set(re.findall(r'url\((https://[^)]+)\)', css)))):
        ext = furl.split('.')[-1].split('?')[0]
        fname = 'f%d.%s' % (i, ext)
        open(os.path.join(fdir, fname), 'wb').write(get(furl))
        css = css.replace(furl, 'fonts/' + fname)
    open(os.path.join(LIBS, 'fonts.css'), 'w', encoding='utf-8').write(css)
    html = html.replace(url, 'libs/fonts.css')

open(IDX, 'w', encoding='utf-8').write(html)
print('OK -> all libraries are now local (offline-ready)')
