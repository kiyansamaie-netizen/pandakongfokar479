# نگهبانان دژ — پروژه‌ی ساخت APK

این پوشه همه‌چیز لازم برای تبدیل بازی (`www/index.html`) به APK اندروید را دارد. بازی با Capacitor داخل یک WebView اجرا می‌شود.

> **حقوق:** مدل‌ها، موسیقی و صداهای داخل بازی (پاندا، کای، تایلانگ، بروسلی، ابومینیشن، لوگو، آهنگ هانس زیمر و ...) محتوای دارای حق نشر هستند. برای نسخه‌ی شخصی مشکلی ندارد؛ برای انتشار در گوگل‌پلی/کافه‌بازار و ... باید مجوزشان را داشته باشی.

## ساختار پوشه
```
www/index.html            ← خود بازی (تک‌فایل، ~۶.۵ مگابایت)
scripts/localize.py       ← کتابخانه‌ها و فونت‌ها را دانلود می‌کند تا APK بدون اینترنت کار کند
scripts/patch_android.py  ← قفل پرتره، تمام‌صفحه و آیکون برنامه
resources/icon.png        ← آیکون ۱۰۲۴×۱۰۲۴ (قابل تعویض)
capacitor.config.json     ← نام برنامه و شناسه‌ی بسته (com.castledefense.game)
.github/workflows/build-apk.yml ← ساخت خودکار APK روی GitHub (بدون نصب اندروید استودیو)
```

## روش ۱ (ساده‌ترین، بدون نصب چیزی): GitHub Actions
1. در github.com یک حساب و یک مخزن (Repository) جدید بساز.
2. کل محتوای همین پوشه را داخل مخزن آپلود کن (Add file ← Upload files؛ پوشه‌ی `.github` هم باید باشد).
3. به تب **Actions** برو ← workflow با نام «Build Android APK» ← **Run workflow**.
4. بعد از حدود ۵ تا ۱۰ دقیقه، در پایین صفحه‌ی همان اجرا در بخش **Artifacts** فایل `castle-defense-apk` را دانلود کن؛ داخلش `app-debug.apk` است.
5. APK را روی گوشی نصب کن (اجازه‌ی «نصب از منبع ناشناس» را بده).

این روش خودش `localize.py` را اجرا می‌کند، پس APK **آفلاین** کار می‌کند.

## روش ۲: روی کامپیوتر خودت (Android Studio)
پیش‌نیاز: Node.js 18+، Java 17، Android Studio، Python 3 و pip install pillow
```bash
python3 scripts/localize.py      # دانلود کتابخانه‌ها (نیاز به اینترنت)
npm install
npx cap add android
python3 scripts/patch_android.py
npx cap sync android
npx cap open android             # Android Studio باز می‌شود
# در Android Studio:  Build ← Build Bundle(s)/APK(s) ← Build APK(s)
# یا در ترمینال:  cd android && ./gradlew assembleDebug
```
خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

## روش ۳: سرویس‌های آنلاین (بدون کد)
می‌توانی `www` را به‌صورت zip به سرویس‌هایی مثل WebIntoApp، AppsGeyser یا Median.co بدهی. **حتماً قبلش** یک بار `python3 scripts/localize.py` را اجرا کن (یا بازی فقط با اینترنت کار می‌کند).

## نسخه‌ی نهایی (Release) و امضا
APK دیباگ برای نصب شخصی کافی است. برای انتشار:
```bash
keytool -genkey -v -keystore my.keystore -alias game -keyalg RSA -keysize 2048 -validity 10000
# در Android Studio: Build ← Generate Signed Bundle / APK
```

## نکته‌های فنی
- بازی با WebView سیستم اجرا می‌شود؛ WebGL لازم است (همه‌ی گوشی‌های امروزی دارند).
- آهنگ بعد از اولین لمس صفحه شروع می‌شود (محدودیت WebView).
- اگر گوشی ضعیف است، در تنظیمات بازی «کیفیت گرافیک» را روی «پایین» و «افکت‌های سینمایی» را خاموش بگذار.
- ذخیره‌ی بازی با LocalStorage انجام می‌شود و با بستن برنامه می‌ماند.
- اگر خطایی دیدی: گوشی را با USB وصل کن و در کروم کامپیوتر `chrome://inspect` را باز کن (دیباگ وب‌ویو فعال است).
